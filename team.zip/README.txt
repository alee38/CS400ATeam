README

Course: cs400
Semester: Spring 2019
Project name: CompHelp Inventory
Team Members:
1. Andrew Lee, Lecture 001, alee38@wisc.edu
2. Qinglang Ye, Lecture 001, qye25@wisc.edu
3. Di Bao, Lecture 001, dbao5@wisc.edu
4. Chengze Qian, Lecture 001, cqian43@wisc.edu
5. Xiaoyu Liu, Lecture 001, xliu725@wisc.edu

Notes or comments to the grader:

Item description return button requires double click.
Everything should work, but we encounter some issues when some people
	clone the repository. It might be a difference in Java versions.


